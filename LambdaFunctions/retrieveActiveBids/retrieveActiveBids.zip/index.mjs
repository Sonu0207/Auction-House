import mysql from 'mysql';

export const handler = async (event) => {
  let response = undefined;

  const pool = mysql.createPool({
      host: process.env.host,
      user: process.env.user,
      password: process.env.password,
      database: process.env.database
  });
  
  const retrieveActiveBids = (buyerUsername, authKey) => {
    return new Promise((resolve, reject) => {
      pool.query("SELECT username FROM buyerTable WHERE username=? and authKey=?", [buyerUsername, authKey], (error, rows) => {
          if (error) { return reject(error) }
              if ((rows) && (rows.length != 0)) {
                pool.query("SELECT itemName, bidAmount, date FROM itemTable JOIN bidTable ON itemTable.itemID = bidTable.itemId WHERE bidTable.buyerUsername=?", [buyerUsername], (error, rows) => {
                    if (error) { return reject(error) }
                    if ((rows) && (rows.length != 0)) {
                      return resolve(false)
                    } else {
                        return resolve("Available funds not updated")
                    }
                });
              } else {
                  return resolve("Available funds not updated")
              }
        }
      );
    });
  };

  try {
    const result = await retrieveActiveBids(event.buyerUsername, event.authKey);
    response = {
      statusCode: result ? 200 : 400,
      body: result ? { response: "Active bids successfully retrieved" } : { response: "Active bids not retrieved" }
    };
  } catch (error) {
    response = {
      statusCode: 500,
      body: { error: error.message }
    };
  }

  pool.end();
  return response;
};
