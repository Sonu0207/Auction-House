import mysql from 'mysql';

export const handler = async (event) => {
    // Create a pool for MySQL connections
    const pool = mysql.createPool({
        host: process.env.host,
        user: process.env.user,
        password: process.env.password,
        database: process.env.database,
    });

    // Function to add funds to the buyer's account
    const addFundsToBuyerAccount = (username, amount) => {
        return new Promise((resolve, reject) => {
            // Check if the amount is valid
            if (amount <= 0) {
                return reject("Invalid amount. Please enter a positive value.");
            }

            // Query to update available funds and total funds
            const query = `
                UPDATE buyerTable 
                SET availableFunds = availableFunds + ?, 
                    totalFunds = totalFunds + ? 
                WHERE username = ?`;
            pool.query(query, [amount, amount, username], (error, results) => {
                if (error) {
                    return reject(error);
                }
                if (results.affectedRows === 0) {
                    return reject("Buyer not found.");
                }
                resolve("Funds added successfully.");
            });
        });
    };

    // Default response
    let result = {
        statusCode: 400,
        body: "Couldn't process the request",
    };

    // Extracting data from the event
    const { username, amount } = event;

    try {
        // Add funds to the buyer's account
        const message = await addFundsToBuyerAccount(username, amount);
        result = {
            statusCode: 200,
            body: { message },
        };
    } catch (error) {
        result = {
            statusCode: 400,
            body: error,
        };
    } finally {
        pool.end(); // End the database connection pool
    }

    return result; // Return the response
};
