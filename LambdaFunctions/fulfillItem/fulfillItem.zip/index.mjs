import mysql from 'mysql';

export const handler = async (event) => {
  let response = undefined;

  const pool = mysql.createPool({
      host: process.env.host,
      user: process.env.user,
      password: process.env.password,
      database: process.env.database
  });
  
  const fulfillItem = (sellerUsername, authKey, itemId) => {
    let buyer = null;
    return new Promise((resolve, reject) => {
      pool.query("SELECT username FROM sellerTable WHERE username=? and authKey=?", [sellerUsername, authKey], (error, rows) => {
          if (error) { return reject(error) }
              if ((rows) && (rows.length != 0)) {
                pool.query("SELECT buyerUsername, MAX(bidAmount) as finalPrice FROM bidTable WHERE itemId=?" [itemId], (error, rows) => {
                    if (error) { return reject(error) }
                    if ((rows) && (rows.length != 0)) {
                      buyer = rows[0].buyerUsername
                      pool.query("UPDATE buyerTable SET totalFunds=totalFunds-? WHERE username=?" [rows[0].finalPrice, buyer], (error, rows) => {
                          if (error) { return reject(error) }
                          if ((rows) && (rows.length != 0)) {
                            pool.query("SELECT buyerUsername, MAX(bidAmount) as returnFunds from bidTable where itemId=? and buyerUsername != ? group by buyerUsername" [itemId, buyer], (error, rows) => {
                                if (error) { return reject(error) }
                                if ((rows) && (rows.length != 0)) {
                                  for(let i = 0; i < rows.length; i++){
                                    pool.query("UPDATE buyerTable SET availableFunds=availableFunds+? WHERE buyerUsername=?" [rows[i].returnFunds, rows[i].buyerUsername], (error, rows) => {
                                        if (error) { return reject(error) }
                                        if ((rows) && (rows.length != 0)) {
                                          pool.query("UPDATE itemTable SET fullfilled=True, active=False WHERE itemId=?" [itemId], (error, rows) => {
                                              if (error) { return reject(error) }
                                              if ((rows) && (rows.length != 0)) {
                                                return resolve(rows)
                                              } else {
                                                  return resolve(false)
                                              }
                                          });
                                        } else {
                                            return resolve(false)
                                        }
                                    });
                                  }
                                } else {
                                    return resolve(false)
                                }
                            });
                          } else {
                              return resolve("No other bids on item")
                          }
                      });
                    } else {
                        return resolve(false)
                    }
                });
              } else {
                  return resolve(false)
              }
        }
      );
    });
  };

  let result = await fulfillItem(event.sellerUsername, event.authKey, event.itemId)

  if(result){
    response = {
      statusCode: 200,
      body: {"response": result}
    }
  }
  else{ 
    response = { 
      statusCode: 400, 
      body: {"response" : result}
    }
  }
  pool.end(); 
  return response; 
}