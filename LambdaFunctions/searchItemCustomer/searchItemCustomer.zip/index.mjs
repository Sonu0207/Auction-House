import mysql from 'mysql';

export const handler = async (event) => {
    let response;
    
    const searchQuery = event.queryStringParameters?.searchQuery || '';
    
    if (!searchQuery) {
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Search query is required.' })
        };
    }
    
    const pool = mysql.createPool({
        host: process.env.host,
        user: process.env.user,
        password: process.env.password,
        database: process.env.database
    });

    // Query to search items by substring in itemName or description
    const searchItems = () => {
        return new Promise((resolve, reject) => {
            const query = `
                SELECT * 
                FROM itemTable 
                WHERE active = true 
                AND (itemName LIKE ? OR description LIKE ?)`;

            const queryParams = [`%${searchQuery}%`, `%${searchQuery}%`];

            pool.query(query, queryParams, (error, results) => {
                if (error) {
                    return reject(error);
                }
                resolve(results);
            });
        });
    };

    try {
        const items = await searchItems();

        response = {
            statusCode: 200,
            body: JSON.stringify(items.length > 0 ? items : { message: 'No items found.' })
        };
    } catch (error) {
        console.error('Error querying items:', error);

        response = {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error fetching items.', error: error.message })
        };
    } finally {
        pool.end(); // Close the database connection pool
    }

    return response;
};