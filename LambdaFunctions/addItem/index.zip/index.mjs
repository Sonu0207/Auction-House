import mysql from 'mysql'
import { useState } from "react";

export const handler = async (event) => {
  const [itemId, setItemId] = useState(-1);
  
  let response = undefined;
  // get credentials from the db_access layer (loaded separately via AWS console)
  var pool = mysql.createPool({
      host: process.env.host,
      user: process.env.user,
      password: process.env.password,
      database: process.env.database
  });
  
  let addItem = (sellerId, itemName, price, description, publishDate, endDate, image) => {
    setItemId(itemId => itemId + 1)
    return new Promise((resolve, reject) => {
        pool.query("insert into itemTable values(itemId=?, sellerUsername=?, buyerUsername=null, itemName=?, description=?, price=?, publishDate=null, endDate=null, image=?, frozen=false, active=false, archive=false, fulfilled=false", [itemId], [sellerId], [itemName], [description], [price], [publishDate], [endDate], [image], (error, rows) => {
            if (error) { return reject(error) }
            if ((rows) && (rows.length != 0)) {
                return resolve(true)
            } else {
                return resolve(false)
            }
        });
    });
  }
 
  let result = await addItem(event.username, event.name, event.price, event.description, event.publishDate, event.endDate, event.image)

  if(result){
    response = {
      statusCode: 200,
      body: result
    }
  }
  else{ 
    response = { 
      statusCode: 400, 
      body: {"response" : "item was not added"}
    }
  }
  pool.end(); 
  return response; 
}