import mysql from 'mysql';

export const handler = async (event) => {
  let response = undefined;

  const pool = mysql.createPool({
      host: process.env.host,
      user: process.env.user,
      password: process.env.password,
      database: process.env.database
  });
  
  const removeInactiveItem = (sellerId, itemId) => {
    return new Promise((resolve, reject) => {
      pool.query(
        "SELECT * FROM itemTable WHERE sellerUsername = ? AND itemId = ? AND buyerUsername is null and active = false", 
        [sellerId, itemId], 
        (error, rows) => {
          if (error) return reject(error);
          if(rows[0].endDate < NOW()){
            resolve(false)
          }
          else if (rows && rows.length > 0 && !rows[0].active) {
            pool.query(
              "Delete FROM itemTable WHERE sellerUsername = ? AND itenID = ?", 
              [sellerId, itemId], 
              (error, result) => {
                if (error) return reject(error);
                resolve(result.affectedRows > 0);
              }
            );
          } else {
            resolve(false);
          }
        }
      );
    });
  };

  try {
    const result = await removeInactiveItem(event.username, event.itemId);
    response = {
      statusCode: result ? 200 : 400,
      body: result ? { response: "item removed successfully" } : { response: "item was not removed" }
    };
  } catch (error) {
    response = {
      statusCode: 500,
      body: { error: error.message }
    };
  }

  pool.end();
  return response;
};
