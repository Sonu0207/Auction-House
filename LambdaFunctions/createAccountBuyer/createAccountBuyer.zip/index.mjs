import mysql from 'mysql';
import crypto from 'crypto';

const buffer32 = [80, 122, 102, 248, 50, 254, 122, 218, 1, 245, 190, 221, 131, 249, 40, 113, 54, 111, 70, 48, 0, 101, 248, 173, 125, 24, 250, 181, 18, 226, 168, 127];
const secretKey = Buffer.from(buffer32);

export const handler = async (event) => {
    const pool = mysql.createPool({
        host: process.env.host,
        user: process.env.user,
        password: process.env.password,
        database: process.env.database
    });

    // Encrypt password
    function encrypt(password) {
        const iv = crypto.randomBytes(16); // Generate a random IV
        const cipher = crypto.createCipheriv('aes-256-cbc', secretKey, iv);
        let encrypted = cipher.update(password, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        return { iv: iv.toString('hex'), encryptedData: encrypted };
    }

    // Check if username already exists
    const checkUsernameExists = (username) => {
        return new Promise((resolve, reject) => {
            pool.query("SELECT * FROM buyerTable WHERE username = ?", [username], (error, rows) => {
                if (error) return reject(error);
                resolve(rows.length > 0); // Return true if username exists
            });
        });
    };

    // Create a new buyer account
    const createBuyerAccount = (username, password) => {
        return new Promise((resolve, reject) => {
            const { iv, encryptedData } = encrypt(password);
            // Insert the new buyer account with default funds set to 0
            pool.query("INSERT INTO buyerTable (username, password, totalFunds, availableFunds) VALUES (?, ?, 0, 0)", 
            [username, encryptedData], (error) => {
                if (error) return reject(error);
                resolve();
            });
        });
    };

    let result;
    try {
        const { username, password } = event; // Expecting username and password from the event

        // Check if username already exists
        const userExists = await checkUsernameExists(username);
        if (userExists) {
            result = {
                statusCode: 400,
                body: "Username already exists."
            };
            return result;
        }

        // Create new buyer account
        await createBuyerAccount(username, password);
        result = {
            statusCode: 201,
            body: { message: "Account created successfully." }
        };
    } catch (error) {
        console.error(error);
        result = {
            statusCode: 500,
            body: "Internal server error."
        };
    } finally {
        pool.end(); 
    }

    return result;
};
